/* lib/version.h.  Generated from version.h.in by configure.
 *
 * Quagga version
 * Copyright (C) 1997, 1999 Kunihiro Ishiguro
 * 
 * This file is part of GNU Zebra.
 *
 * GNU Zebra is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2, or (at your option) any
 * later version.
 *
 * GNU Zebra is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with GNU Zebra; see the file COPYING.  If not, write to the Free
 * Software Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA
 * 02111-1307, USA.  
 */

#ifndef _ZEBRA_VERSION_H
#define _ZEBRA_VERSION_H

#ifdef GIT_VERSION
#include "gitversion.h"
#endif

#ifndef GIT_SUFFIX
#define GIT_SUFFIX ""
#endif
#ifndef GIT_INFO
#define GIT_INFO ""
#endif

#define FRR_PAM_NAME    "frr"
#define FRR_SMUX_NAME   "frr"
#define FRR_PTM_NAME    "frr"

#define FRR_FULL_NAME   "FRRouting"
#define FRR_VERSION     "3.0.2" GIT_SUFFIX
#define FRR_VER_SHORT   "3.0.2"
#define FRR_BUG_ADDRESS "https://github.com/frrouting/frr/issues"
#define FRR_COPYRIGHT   "Copyright 1996-2005 Kunihiro Ishiguro, et al."
#define FRR_CONFIG_ARGS " '--build=x86_64-linux-gnu' '--prefix=/usr' '--includedir=${prefix}/include' '--mandir=${prefix}/share/man' '--infodir=${prefix}/share/info' '--sysconfdir=/etc' '--localstatedir=/var' '--disable-silent-rules' '--libexecdir=${prefix}/lib/frr' '--disable-maintainer-mode' '--disable-dependency-tracking' '--enable-exampledir=/usr/share/doc/frr/examples/' '--localstatedir=/var/run/frr' '--sbindir=/usr/lib/frr' '--sysconfdir=/etc/frr' '--enable-ospfapi=yes' '--enable-multipath=256' '--enable-ldpd' '--enable-fpm' '--enable-user=frr' '--enable-group=frr' '--enable-vty-group=frrvty' '--enable-configfile-mask=0640' '--enable-logfile-mask=0640' '--enable-werror' '--with-libpam' '--enable-systemd=yes' '--enable-poll=yes' '--enable-cumulus=no' '--enable-pimd' '--enable-dependency-tracking' '--enable-bgp-vnc=yes' 'CFLAGS=-g -O2 -fPIE -fstack-protector-strong -Wformat -Werror=format-security' 'CPPFLAGS=-D_FORTIFY_SOURCE=2' 'CXXFLAGS=-g -O2 -fPIE -fstack-protector-strong -Wformat -Werror=format-security' 'FCFLAGS=-g -O2 -fPIE -fstack-protector-strong' 'FFLAGS=-g -O2 -fPIE -fstack-protector-strong' 'GCJFLAGS=-g -O2 -fPIE -fstack-protector-strong' 'LDFLAGS=-fPIE -pie -Wl,-z,relro -Wl,-z,now' 'OBJCFLAGS=-g -O2 -fPIE -fstack-protector-strong -Wformat -Werror=format-security' 'OBJCXXFLAGS=-g -O2 -fPIE -fstack-protector-strong -Wformat -Werror=format-security' 'build_alias=x86_64-linux-gnu'"

#define FRR_DEFAULT_MOTD \
	"\r\n" \
	"Hello, this is " FRR_FULL_NAME " (version " FRR_VERSION ").\r\n" \
	FRR_COPYRIGHT "\r\n" \
	GIT_INFO "\r\n"

pid_t pid_output (const char *);

#endif /* _ZEBRA_VERSION_H */
